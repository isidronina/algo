# Projeto Piata Norte — HTML, CSS e JavaScript

Esta pasta é uma versão independente do projeto Angular. O projeto Angular original não foi alterado.

## Como executar
1. Abra esta pasta no VS Code.
2. Execute `index.html` com a extensão **Live Server**.
3. Não abra o arquivo diretamente com `file://`, pois os componentes são carregados com `fetch()` e precisam de um servidor local.

## Organização
- `index.html`: página inicial e ponto de entrada.
- `paginas/`: HTML e CSS separados de cada página.
- `componentes/`: componentes HTML e CSS reutilizáveis.
- `js/app.js`: navegação e carregamento dos componentes.
- `js/firebase/`: arquivos separados para configuração, autenticação e operações com orçamentos.
- `assets/`: imagens originais do projeto.

## Firebase
A integração está preparada, mas desativada até a configuração:
1. Abra `js/firebase/firebase-config.js`.
2. Substitua os textos de exemplo pelos dados do aplicativo Web do Firebase.
3. Habilite Authentication (método E-mail/senha) e Firestore no console Firebase.
4. Configure regras de segurança adequadas para `users` e `orcamentos`.
5. Depois, conecte as ações das telas aos métodos em `auth.js` e `orcamentos.js`.

**Importante:** no estado atual, as telas e a navegação estão preparadas para demonstração. Login, cadastro e operações do painel ainda não fazem gravações reais. A integração Firebase não foi ativada nem testada porque isso exige configuração e credenciais do projeto e testes no ambiente Firebase.

## Observação sobre a conversão
Os arquivos HTML/CSS originais foram usados como base e os estilos foram mantidos. As marcações específicas do Angular foram retiradas para produzir HTML independente; isso significa que expressões e diretivas do Angular não são executadas nesta versão. As funcionalidades que dependiam de TypeScript/Angular precisam ser reimplementadas e testadas em JavaScript puro, etapa que pode ser feita gradualmente.
