// AUTENTICAÇÃO FIREBASE — preparada para ativação.
import { auth, iniciarFirebase } from "./firebase.js";

export async function cadastrarComFirebase(nome, email, senha) {
  if (!await iniciarFirebase()) throw new Error("Firebase ainda não foi configurado.");
  const { createUserWithEmailAndPassword } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js");
  const { doc, setDoc, serverTimestamp } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js");
  const credencial = await createUserWithEmailAndPassword(auth, email, senha);
  const { db } = await import("./firebase.js");
  await setDoc(doc(db, "users", credencial.user.uid), {
    uid: credencial.user.uid, nome, email, criadoEm: serverTimestamp()
  }, { merge: true });
  return credencial.user;
}

export async function entrarComFirebase(email, senha) {
  if (!await iniciarFirebase()) throw new Error("Firebase ainda não foi configurado.");
  const { signInWithEmailAndPassword } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js");
  return signInWithEmailAndPassword(auth, email, senha);
}

export async function sairDoFirebase() {
  if (!auth) return;
  const { signOut } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js");
  return signOut(auth);
}

export async function redefinirSenhaFirebase(email) {
  if (!await iniciarFirebase()) throw new Error("Firebase ainda não foi configurado.");
  const { sendPasswordResetEmail } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js");
  return sendPasswordResetEmail(auth, email);
}
