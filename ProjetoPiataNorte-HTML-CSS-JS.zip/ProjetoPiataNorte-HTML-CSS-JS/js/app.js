// NAVEGAÇÃO E COMPONENTIZAÇÃO EM JAVASCRIPT PURO
const rotas = {
  "/": "inicio",
  "/inicio": "inicio",
  "/login": "login",
  "/cadastro": "cadastro",
  "/dashboard": "dashboard",
  "/orcamento": "orcamento",
  "/preview": "preview"
};

const paginasComMenu = new Set(["dashboard", "orcamento", "preview", "cadastro"]);

async function carregarArquivo(caminho) {
  const resposta = await fetch(caminho);
  if (!resposta.ok) throw new Error(`Não foi possível carregar ${caminho}`);
  return resposta.text();
}

async function inserirComponente(nome, alvo) {
  const [html] = await Promise.all([
    carregarArquivo(`componentes/${nome}.html`)
  ]);
  alvo.innerHTML = html;
  const css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = `componentes/${nome}.css`;
  css.dataset.componente = nome;
  if (!document.querySelector(`[data-componente="${nome}"]`)) document.head.append(css);
}


async function montarComponentes(raiz) {
  const slots = [...raiz.querySelectorAll("[data-componente]")];
  for (const slot of slots) {
    const nome = slot.dataset.componente;
    const html = await carregarArquivo(`componentes/${nome}.html`);
    slot.innerHTML = html;
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = `componentes/${nome}.css`;
    css.dataset.componenteCss = nome;
    if (!document.querySelector(`[data-componente-css="${nome}"]`)) document.head.append(css);
    if (nome === "menu-superior") {
      const texto = slot.dataset.paginaAtual || "";
      const crumb = slot.querySelector(".topbar__crumb");
      if (crumb) crumb.textContent = `>Sistema de orçamentos / ${texto}`;
      await montarComponentes(slot);
    }
    if (nome === "cartao-resumo") {
      const label = slot.dataset.rotulo || "Resumo";
      const sub = slot.dataset.subtexto || "";
      slot.innerHTML = `<div class="summary-card ${label === "Em produção" ? "summary-card--progress" : ""}">
        <span class="summary-card__label">${label}</span>
        <strong class="summary-card__number">0</strong>
        <span class="summary-card__sub">${sub}</span></div>`;
    }
    if (nome === "usuario") {
      const nomeUsuario = slot.querySelector(".dropdown__name");
      if (nomeUsuario) nomeUsuario.textContent = "Usuário";
      const sair = slot.querySelector(".logout");
      sair?.addEventListener("click", () => navegar("/login"));
    }
  }
}

async function navegar(caminho, adicionarHistorico = true) {
  const url = new URL(caminho, location.origin);
  const nomePagina = rotas[url.pathname] || "nao-encontrado";
  if (adicionarHistorico) history.pushState({}, "", url.pathname + url.search);
  const app = document.querySelector("#app");
  app.innerHTML = '<div class="app-shell"><main id="conteudo-pagina"></main></div>';
  const main = app.querySelector("#conteudo-pagina");

  try {
    main.innerHTML = await carregarArquivo(`paginas/${nomePagina}.html`);
    const cssId = `pagina-${nomePagina}`;
    if (!document.querySelector(`[data-pagina-css="${cssId}"]`)) {
      const css = document.createElement("link");
      css.rel = "stylesheet";
      css.href = `paginas/${nomePagina}.css`;
      css.dataset.paginaCss = cssId;
      document.head.append(css);
    }
    if (paginasComMenu.has(nomePagina)) {
      const shell = app.querySelector(".app-shell");
      const menu = document.createElement("aside");
      menu.className = "menu-lateral-container";
      shell.prepend(menu);
      await inserirComponente("menu-lateral", menu);
    }
    await montarComponentes(main);
    configurarPagina(nomePagina);
  } catch (erro) {
    console.error(erro);
    main.innerHTML = "<h1>Não foi possível abrir esta página.</h1><p>Execute o projeto com Live Server ou outro servidor local.</p>";
  }
}

function configurarPagina(pagina) {
  document.querySelectorAll('a[href^="/"]').forEach(link => {
    link.addEventListener("click", evento => {
      evento.preventDefault();
      navegar(link.getAttribute("href"));
    });
  });

  if (pagina === "login") configurarLogin();
  if (pagina === "cadastro") configurarCadastro();
  if (pagina === "dashboard") configurarDashboardDemo();
  if (pagina === "orcamento") configurarFormularioDemo();
  if (pagina === "preview") configurarPreviewDemo();
}

function configurarLogin() {
  const form = document.querySelector("form");
  if (!form) return;
  const senha = document.querySelector('input[type="password"]');
  const botao = document.querySelector(".password__toggle");
  botao?.addEventListener("click", () => {
    if (!senha) return;
    senha.type = senha.type === "password" ? "text" : "password";
    botao.textContent = senha.type === "password" ? "Mostrar" : "Ocultar";
  });
  form.addEventListener("submit", async evento => {
    evento.preventDefault();
    const email = form.querySelector('input[type="email"]')?.value.trim();
    const password = form.querySelector('input[type="password"], input[type="text"]')?.value;
    const feedback = document.querySelector(".erro") || document.createElement("p");
    feedback.className = "erro";
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password) {
      feedback.textContent = "Informe um e-mail válido e sua senha.";
      form.append(feedback); return;
    }
    feedback.textContent = "A tela está pronta. Configure o Firebase para autenticar usuários reais.";
    form.append(feedback);
  });
}

function configurarCadastro() {
  const form = document.querySelector("form");
  if (!form) return;
  form.addEventListener("submit", evento => {
    evento.preventDefault();
    const feedback = document.querySelector('[style*="color: #dc2626"]') || document.createElement("p");
    feedback.textContent = "Formulário validado visualmente. Configure o Firebase para cadastrar usuários reais.";
    form.append(feedback);
  });
}

function configurarDashboardDemo() {
  // A estrutura visual da tabela é preservada; dados reais serão carregados pelo Firestore após a configuração.
  const busca = document.querySelector('input[aria-label="Buscar orçamentos"]');
  busca?.addEventListener("input", () => {
    const termo = busca.value.toLocaleLowerCase("pt-BR");
    document.querySelectorAll(".budget-row, .table-row, tbody tr").forEach(linha => {
      linha.hidden = !linha.textContent.toLocaleLowerCase("pt-BR").includes(termo);
    });
  });
}

function configurarFormularioDemo() {
  const form = document.querySelector("form");
  form?.addEventListener("submit", e => e.preventDefault());
  document.querySelectorAll('input[type="text"], input[type="number"]').forEach(campo => {
    campo.addEventListener("input", () => campo.setCustomValidity(""));
  });
}

function configurarPreviewDemo() {
  document.querySelectorAll("button").forEach(botao => {
    if (/imprimir|pdf/i.test(botao.textContent)) botao.addEventListener("click", () => window.print());
    if (/voltar/i.test(botao.textContent)) botao.addEventListener("click", () => history.back());
  });
}

window.addEventListener("popstate", () => navegar(location.pathname, false));
document.addEventListener("DOMContentLoaded", () => navegar(location.pathname, false));
