// CONFIGURAÇÃO DO FIREBASE
// Quando forem conectar o Firebase, substituam os valores abaixo pelas configurações
// do aplicativo Web encontradas em Configurações do projeto > Seus apps no Firebase.
// Não compartilhem este arquivo com credenciais privadas. A apiKey web do Firebase
// identifica o projeto; a segurança real deve ser feita pelas regras do Firestore/Auth.

export const firebaseConfig = {
  apiKey: "COLE_SUA_API_KEY",
  authDomain: "SEU_PROJETO.firebaseapp.com",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_PROJETO.firebasestorage.app",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID"
};
