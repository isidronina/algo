// OPERAÇÕES DE ORÇAMENTOS NO FIRESTORE — preparadas para ativação.
import { iniciarFirebase } from "./firebase.js";

async function dependencias() {
  if (!await iniciarFirebase()) throw new Error("Firebase ainda não foi configurado.");
  const { db } = await import("./firebase.js");
  const sdk = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js");
  return { db, ...sdk };
}

export async function listarOrcamentos() {
  const { db, collection, getDocs } = await dependencias();
  const resultado = await getDocs(collection(db, "orcamentos"));
  return resultado.docs.map(item => ({ id_orcamento: item.id, ...item.data() }));
}
export async function criarOrcamento(dados) {
  const { db, collection, addDoc } = await dependencias();
  return addDoc(collection(db, "orcamentos"), dados);
}
export async function atualizarOrcamento(id, dados) {
  const { db, doc, updateDoc } = await dependencias();
  return updateDoc(doc(db, "orcamentos", id), dados);
}
export async function excluirOrcamento(id) {
  const { db, doc, deleteDoc } = await dependencias();
  return deleteDoc(doc(db, "orcamentos", id));
}
