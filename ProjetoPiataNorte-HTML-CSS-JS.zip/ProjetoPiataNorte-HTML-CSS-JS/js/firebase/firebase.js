// PONTO ÚNICO DE INTEGRAÇÃO COM O FIREBASE (SDK modular via CDN).
// Para ativar: preencher firebase-config.js e descomentar o bloco abaixo.
// O restante do site não precisa importar Angular.

import { firebaseConfig } from "./firebase-config.js";

export let app = null;
export let auth = null;
export let db = null;

export async function iniciarFirebase() {
  if (app && auth && db) return true;
  if (firebaseConfig.apiKey === "COLE_SUA_API_KEY") {
    console.info("Firebase ainda não configurado. O site está em modo de demonstração.");
    return false;
  }

  const { initializeApp } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js");
  const { getAuth } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js");
  const { getFirestore } = await import("https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js");

  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  return true;
}
